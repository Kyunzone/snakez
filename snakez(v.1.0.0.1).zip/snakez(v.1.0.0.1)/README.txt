THIS PROGRAM SHOULD ONLY BE USED FOR TESTS!!!

the passwort is 39467205
this program should only be used for test purposes.
consequential damage may occur and I will assume NO liability for it.

